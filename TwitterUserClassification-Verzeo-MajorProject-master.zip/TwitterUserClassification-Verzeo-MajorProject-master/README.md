# TwitterUserClassification-Verzeo-MajorProject
A machine learning project on predicting the gender of users based on a twitter user dataset.

This project was done as a part of my Machine Learning Internship at Verzeo Edutech Pvt. Ltd.
